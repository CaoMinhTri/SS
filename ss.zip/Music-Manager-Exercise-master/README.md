# Music Manager Exercise
+ Tomcat 7.0.56 (Download link)
+ Eclipse IDE Luna Service Release 1 v4.4.1(Download link)
+ Spring 4.1.1 (No download required)
+ JDK 1.7 (Download link)
